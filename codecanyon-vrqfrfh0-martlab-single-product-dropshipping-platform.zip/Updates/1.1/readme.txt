HOW TO UPDATE :

Please just upload the file "Update.zip" into the main dir of your server and just extract to main dir. After that import update.sql to your database 


Changes We made :

[FIX] Color order color issue solve
[FIX] Multiple color add issue solve
[FIX] SMS issue solve
[REMOVE] Un-used code removed